import React, { Component } from 'react'

export default class state extends Component {
    constructor() {
        super();
        console.log("call constructor")
        this.clkfn1 = this.clkfn1.bind(this)


        this.state = { data1: "using state....data-1." }
        
        this.state = {data:"use state....."} 
    }

      
    seconddata = <h1>second datatatatatat (data member) </h1>


    //    bind required in constructor 
    clkfn1() {
        console.log("data function click1")
       console.log( this.seconddata)
    }

    // if u use arrow function = not required bind 
    clkfn2 = () => {
        console.log("data function click2")
        console.log(this.seconddata)
        this.seconddata = <h3>third data</h3>

        this.state.data1 = "fourth value"

        
        this.setState({
            data :<h1> new value change </h1>
        
        })
    }

    clkfn3() {
        console.log("function click3")
    }

 


  render() {
      console.log("called render")
       
      let somedata = <h1>boooooomm......</h1>

      return (
        <>
              {somedata}
              {this.seconddata}
             <div>
                  <p> state tu tu hai vahi dilne Lorem ipsum dolor sit amet consectetur, adipisicing elit. Blanditiis quidem animi totam   aut placeat ad.</p>
                  <button onClick={this.clkfn1}>click here 1</button>
             </div>
             <div>
                  <p> state tu tu hai vahi dilne Lorem ipsum dolor sit amet consectetur, adipisicing elit. Blanditiis quidem animi totam   aut placeat ad.</p>
                  <button onClick={this.clkfn2}>click here 2</button>
             </div>
             <div>
                  <p> state tu tu hai vahi dilne Lorem ipsum dolor sit amet consectetur, adipisicing elit. Blanditiis quidem animi totam   aut placeat ad.</p>
                  <button onClick={this.clkfn3}>click here 3</button>
              </div>
              <br /><br />

              {this.state.data}
              {this.state.data1}
        </>
    )
  }
}
