import React, { Component } from 'react'
import { Route, Routes } from 'react-router-dom'
import Constructor from './constructor'
import Introclass from './introclass'
import State from './state.jsx' 

export default class Classrouter extends Component {
  render() {
    return (
        <>
            
            <Routes>
                    <Route path='/' element={<Introclass></Introclass>}>
                        <Route path='constructor' element={<Constructor></Constructor>}></Route>
                        <Route path='state' element={<State></State>}></Route>
                     </Route>
               
        </Routes>
      </>
    )
  }
}
