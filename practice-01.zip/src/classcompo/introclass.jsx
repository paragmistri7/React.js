import React, { Component } from 'react'
import { Link, Outlet } from 'react-router-dom'


export default class Introclass extends Component {
  render() {
    return (
      <>
        <br />
        <div className="row offset-5 fs-4 " >                                                                    <li ><Link to="constructor"> Constructor</Link></li>
        </div>
        

            <Outlet></Outlet>
      </>
    )
  }
}
