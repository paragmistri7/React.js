import React, { Suspense } from 'react'
import { Route, Routes } from 'react-router-dom'

import Mainfile from './mainfile'
import Home from './home.jsx'
import Example from './mainexample'
// import Classrouter from '../classcompo/classrouter'

const Mainrouter = () => {

const Classrouter = React.lazy (()=>{return import("../classcompo/classrouter")})

  return (
      <>
        
          <Routes>
             <Route path='/' element={<Mainfile></Mainfile>}>
                  <Route path='home' element={<Home></Home>}></Route>
                  <Route path='example/*' element={<Example></Example>}>
                         <Route path='classcom/*' element={<Suspense fallback={<h1>loading...</h1>}><Classrouter></Classrouter> </Suspense>}/>
                  </Route>                 
             </Route>
          </Routes> 
    </>
  )
}

export default Mainrouter
